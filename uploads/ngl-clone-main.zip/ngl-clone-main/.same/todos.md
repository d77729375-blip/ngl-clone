# NGL Clone Proje Durumu

## Tamamlanan
- [x] Ana sayfa - NGL benzeri tasarım
- [x] Mesaj gönderme API'si
- [x] Admin paneli - mesajları görüntüleme
- [x] Gönderen bilgileri kaydetme (IP, tarayıcı, OS, cihaz)
- [x] CSS düzeltmeleri

## Devam Eden
- [ ] Test ve son kontroller
