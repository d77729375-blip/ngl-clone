import { NextRequest, NextResponse } from "next/server";
import { addMessage, getMessages, parseUserAgent } from "@/lib/store";

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { content } = body;

    if (!content || content.trim() === "") {
      return NextResponse.json({ error: "Mesaj boş olamaz" }, { status: 400 });
    }

    // Get sender info
    const forwardedFor = request.headers.get("x-forwarded-for");
    const realIP = request.headers.get("x-real-ip");
    const senderIP = forwardedFor?.split(",")[0] || realIP || "Bilinmiyor";
    const userAgent = request.headers.get("user-agent") || "Bilinmiyor";

    const { browser, os, device } = parseUserAgent(userAgent);

    const message = addMessage({
      id: Math.random().toString(36).substring(2, 15),
      content: content.trim(),
      senderIP,
      userAgent,
      browser,
      os,
      device,
      timestamp: new Date(),
    });

    return NextResponse.json({ success: true, messageId: message.id });
  } catch (error) {
    return NextResponse.json({ error: "Bir hata oluştu" }, { status: 500 });
  }
}

export async function GET(request: NextRequest) {
  const authHeader = request.headers.get("authorization");

  // Simple auth check (in production use proper auth)
  if (authHeader !== "Bearer admin123") {
    return NextResponse.json({ error: "Yetkisiz erişim" }, { status: 401 });
  }

  const messages = getMessages();
  return NextResponse.json({ messages });
}
